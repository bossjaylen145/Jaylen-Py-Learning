cancel = ['no', 'cancel', 'nope', 'nah', 'n', 'void']
whitespace = ' '
contains_whitespace = False
alternative_words = ['y', 'yes', 'si', 'sure', 'ye', 'yea', 'yep']

